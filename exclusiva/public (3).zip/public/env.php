<?php
header('Content-Type: application/json');

// lê o .env que está na raiz do projeto
$envFile = __DIR__ . '/../.env';
$vars = [];

if (file_exists($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $val) = explode('=', $line, 2);
            $vars[trim($key)] = trim($val);
        }
    }
}

echo json_encode($vars);
