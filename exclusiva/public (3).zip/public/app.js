const { createApp } = Vue;
const vueApp = createApp({
  data() {
    return {
      loading: true,
      modalAberto: false,
      slideshowAberto: false,
      imagemAtualIndex: 0,
      map: null,
      todosImoveis: [],
      imoveisFiltrados: [],
      imovelSelecionado: null,
      favoritos: JSON.parse(localStorage.getItem('favoritos') || '[]'),
      scrollProgress: 0,
      ordenacao: 'relevancia',
      chatInput: '',
      processandoChat: false,
      historicoChat: [],
      gravandoAudio: false,
      audioGravado: false,
      processandoAudio: false,
      mediaRecorder: null,
      audioBlob: null,
      openaiApiKey: localStorage.getItem('openai_api_key') || '',
      filtros: {
        bairro: '',
        cidade: '',
        precoMin: '',
        precoMax: '',
        tipo: '',
        finalidade: ''
      },
      dadosImoveis: [
        {
          "codigo": 3900163,
          "referencia": "013AP",
          "finalidade": "Locação",
          "tipo": "Apartamento",
          "dormitorios": 2,
          "suites": 0,
          "banheiros": 1,
          "salas": 1,
          "garagem": 1,
          "valor": "1800.00",
          "cidade": "Belo Horizonte",
          "estado": "MG",
          "bairro": "Itapoã",
          "logradouro": "Avenida Portugal",
          "numero": "5425",
          "cep": "31710-400",
          "area_total": null,
          "terreno": null,
          "descricao": "APARTAMENTO PARA LOCAÇÃO – BAIRRO ITAPOÃ. Valor R$ 1.800,00. Imóvel com excelente localização e fácil acesso às principais vias da região! Características: 02 quartos com armários planejados, 01 sala aconchegante com rebaixamento em gesso, 01 cozinha com revestimentos de qualidade e armários, 01 banheiro amplo com armário e box de vidro.",
          "lat": "-19.84200940",
          "lng": "-43.96582740",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604142998.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604142998.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604207451.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604202039.jpeg"
          ]
        },
        {
          "codigo": 3846231,
          "referencia": "052TE",
          "finalidade": "Locação",
          "tipo": "Área Privativa",
          "dormitorios": 3,
          "suites": 1,
          "banheiros": 2,
          "salas": 2,
          "garagem": 2,
          "valor": "3500.00",
          "cidade": "Belo Horizonte",
          "estado": "MG",
          "bairro": "Itapoã",
          "logradouro": "Rua General Ephigênio Ruas Santos",
          "numero": "265",
          "cep": "31710-400",
          "area_total": "136.00",
          "terreno": "360.00",
          "descricao": "Apartamento 3 Quartos para locação no bairro Itapoã, localizado na cidade de Belo Horizonte / MG, região Pampulha, ponto de referência Escola Municipal Lídia Angélica. Com 3 dormitórios, sendo 1 suíte, possui 2 banheiros, 2 vagas de garagem cobertas, 2 salas, acomoda 6 pessoas.",
          "lat": "-19.84073910",
          "lng": "-43.95621040",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202507181153141843.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202507181153141843.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202507181153149658.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202507181153149538.jpeg"
          ]
        },
        {
          "codigo": 3897176,
          "referencia": "066CA",
          "finalidade": "Venda",
          "tipo": "Casa",
          "dormitorios": 3,
          "suites": 3,
          "banheiros": 4,
          "salas": 0,
          "garagem": 2,
          "valor": "1980000.00",
          "cidade": "Nova Lima",
          "estado": "MG",
          "bairro": "Jardim Canadá",
          "logradouro": "Holanda",
          "numero": "36",
          "area_total": "370.00",
          "terreno": "531.00",
          "descricao": "Casa a venda no condomínio Ville Des Lacs R$ 1.980.000,00. Casa acabamento luxo no condomínio Ville des Lacs. Lote de 531m² com 370m² de área construída. 3 quartos sendo 1 suíte com amplo closet e 2 semi-suites.",
          "lat": "-20.06036970",
          "lng": "-43.97891510",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508210947339801.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508210947339801.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/20250821094739967.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508210947397768.jpeg"
          ]
        },
        {
          "codigo": 3891313,
          "referencia": "065AP",
          "finalidade": "Venda",
          "tipo": "Área Privativa",
          "dormitorios": 3,
          "suites": 0,
          "banheiros": 1,
          "salas": 1,
          "garagem": 1,
          "valor": "445000.00",
          "cidade": "Belo Horizonte",
          "estado": "MG",
          "bairro": "Santa Amélia",
          "logradouro": "Rua Professor Clóvis de Faria",
          "numero": "131",
          "area_total": "113.00",
          "descricao": "Oportunidade Imperdível no Bairro Santa Amélia. Imóvel com 3 quartos, localizado no 1º pavimento, perfeito para quem busca conforto e praticidade: 113m² de área total, 90m² de área construída.",
          "lat": "-19.84414770",
          "lng": "-43.97394230",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508181006316576.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508181006316576.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508181006339633.jpeg"
          ]
        }
      ]
    }
  },
  computed: {
    contadorTexto() {
      const total = this.imoveisFiltrados.length;
      return total === 1 ? '1 imóvel encontrado' : `${total} imóveis encontrados`;
    },
    especificacoesPrincipais() {
      if (!this.imovelSelecionado) return [];
      return [
        { icon: 'fas fa-bed', label: 'Dormitórios', value: this.imovelSelecionado.dormitorios || 0 },
        { icon: 'fas fa-bath', label: 'Banheiros', value: this.imovelSelecionado.banheiros || 0 },
        { icon: 'fas fa-car', label: 'Garagem', value: this.imovelSelecionado.garagem || 0 },
        { icon: 'fas fa-couch', label: 'Salas', value: this.imovelSelecionado.salas || 0 }
      ];
    },
    especificacoes() {
      if (!this.imovelSelecionado) return [];
      const specs = [
        { icon: 'fas fa-home', label: 'Tipo', value: this.imovelSelecionado.tipo },
        { icon: 'fas fa-calendar-alt', label: 'Finalidade', value: this.imovelSelecionado.finalidade },
        { icon: 'fas fa-bed', label: 'Dormitórios', value: this.imovelSelecionado.dormitorios || 0 },
        { icon: 'fas fa-bath', label: 'Banheiros', value: this.imovelSelecionado.banheiros || 0 },
        { icon: 'fas fa-car', label: 'Garagem', value: this.imovelSelecionado.garagem || 0 },
        { icon: 'fas fa-couch', label: 'Salas', value: this.imovelSelecionado.salas || 0 }
      ];
      if (this.imovelSelecionado.suites) {
        specs.push({ icon: 'fas fa-bed', label: 'Suítes', value: this.imovelSelecionado.suites });
      }
      if (this.imovelSelecionado.area_total) {
        specs.push({ icon: 'fas fa-ruler-combined', label: 'Área Total', value: `${this.imovelSelecionado.area_total} m²` });
      }
      if (this.imovelSelecionado.terreno) {
        specs.push({ icon: 'fas fa-map', label: 'Terreno', value: `${this.imovelSelecionado.terreno} m²` });
      }
      if (this.imovelSelecionado.cep) {
        specs.push({ icon: 'fas fa-mail-bulk', label: 'CEP', value: this.imovelSelecionado.cep });
      }
      return specs;
    },
    descricaoLimpa() {
      if (!this.imovelSelecionado?.descricao) return 'Descrição não disponível.';
      return this.limparDescricao(this.imovelSelecionado.descricao);
    }
  },
  mounted() {
    this.inicializarMapa();
    this.carregarImoveis();
    this.configurarEventos();
    this.configurarScrollProgress();
  },
  methods: {
    inicializarMapa() {
      this.map = new maplibregl.Map({
        container: 'map',
        style: CONFIG.MAP_STYLE_URL,
        center: CONFIG.MAP_CENTER,
        zoom: CONFIG.MAP_ZOOM
      });
      this.map.addControl(new maplibregl.NavigationControl());
      this.map.addControl(new maplibregl.ScaleControl());
      this.map.on('moveend', () => {
        this.filtrarPorAreaVisivel();
      });
      this.map.on('load', () => {
        this.adicionarSourceMarkers();
      });
    },
    adicionarSourceMarkers() {
      this.map.addSource('imoveis', {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: []
        }
      });
      this.map.addLayer({
        id: 'imoveis-markers',
        type: 'circle',
        source: 'imoveis',
        paint: {
          'circle-radius': 8,
          'circle-color': [
            'case',
            ['==', ['get', 'finalidade'], 'Venda'],
            '#10b981',
            '#3b82f6'
          ],
          'circle-stroke-width': 2,
          'circle-stroke-color': '#ffffff'
        }
      });
      this.map.on('click', 'imoveis-markers', (e) => {
        const codigo = e.features[0].properties.codigo;
        this.abrirModal(codigo);
      });
      this.map.on('mouseenter', 'imoveis-markers', () => {
        this.map.getCanvas().style.cursor = 'pointer';
      });
      this.map.on('mouseleave', 'imoveis-markers', () => {
        this.map.getCanvas().style.cursor = '';
      });
    },
    filtrarPorAreaVisivel() {
      if (!this.map || !this.todosImoveis.length) return;
      const bounds = this.map.getBounds();
      const imoveisVisiveis = this.todosImoveis.filter(imovel => {
        if (!imovel.lat || !imovel.lng) return false;
        const lat = parseFloat(imovel.lat);
        const lng = parseFloat(imovel.lng);
        return lat >= bounds.getSouth() &&
               lat <= bounds.getNorth() &&
               lng >= bounds.getWest() &&
               lng <= bounds.getEast();
      });
      this.imoveisFiltrados = imoveisVisiveis;
      this.aplicarFiltrosComAreaVisivel(this.imoveisFiltrados);
      this.atualizarMapa();
    },
    aplicarFiltrosComAreaVisivel(imoveisVisiveis = null) {
      const imoveisParaFiltrar = imoveisVisiveis || this.todosImoveis;
      const bairro = this.filtros.bairro.toLowerCase().trim();
      const cidade = this.filtros.cidade.toLowerCase().trim();
      const tipo = this.filtros.tipo.toLowerCase().trim();
      const finalidade = this.filtros.finalidade.toLowerCase().trim();
      const precoMin = parseFloat(this.filtros.precoMin) || 0;
      const precoMax = parseFloat(this.filtros.precoMax) || Infinity;
      this.imoveisFiltrados = imoveisParaFiltrar.filter(imovel => {
        const matchBairro = !bairro || imovel.bairro.toLowerCase().includes(bairro);
        const matchCidade = !cidade || imovel.cidade.toLowerCase().includes(cidade);
        const matchTipo = !tipo || imovel.tipo.toLowerCase().includes(tipo);
        const matchFinalidade = !finalidade || imovel.finalidade.toLowerCase().includes(finalidade);
        const valor = parseFloat(imovel.valor);
        const matchPreco = valor >= precoMin && valor <= precoMax;
        return matchBairro && matchCidade && matchTipo && matchFinalidade && matchPreco;
      });
      this.aplicarOrdenacao();
    },
    configurarEventos() {
      document.addEventListener('keydown', (e) => {
        if (e.keyCode === 27) {
          if (this.slideshowAberto) {
            this.fecharSlideshow();
          } else if (this.modalAberto) {
            this.fecharModal();
          }
        }
        if (this.slideshowAberto) {
          if (e.keyCode === 37) {
            this.imagemAnterior();
          } else if (e.keyCode === 39) {
            this.proximaImagem();
          }
        }
      });
    },
    configurarScrollProgress() {
      window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset;
        const docHeight = document.body.offsetHeight;
        const winHeight = window.innerHeight;
        const scrollPercent = scrollTop / (docHeight - winHeight);
        this.scrollProgress = Math.min(scrollPercent, 1);
      });
    },
    async carregarImoveis() {
      this.loading = true;
      try {
        const response = await fetch(CONFIG.API_URLS.EXTERNAL, {
          method: 'GET',
          headers: {
            'ngrok-skip-browser-warning': 'true'
          }
        });
        if (response.ok) {
          const data = await response.json();
          console.log('Dados carregados da API externa:', data);
          this.processarDados(data);
        } else {
          throw new Error('API externa não disponível');
        }
      } catch (error) {
        console.warn('API externa não disponível, tentando API local:', error);
        try {
          const response = await fetch(CONFIG.API_URLS.LOCAL, {
            method: 'GET'
          });
          if (response.ok) {
            const data = await response.json();
            console.log('Dados carregados da API local:', data);
            this.processarDados(data);
          } else {
            throw new Error('API local não disponível');
          }
        } catch (localError) {
          console.warn('APIs não disponíveis, usando dados locais:', localError);
          this.processarDados({ data: this.dadosImoveis, status: true });
        }
      }
    },
    processarDados(response) {
      this.loading = false;
      if (!response || !response.data || response.data.length === 0) {
        this.todosImoveis = [];
        this.imoveisFiltrados = [];
        return;
      }
      this.todosImoveis = response.data;
      this.imoveisFiltrados = [...this.todosImoveis];
      this.filtrarPorAreaVisivel();
      this.atualizarMapa();
    },
    aplicarFiltros() {
      const imoveisNoMapa = this.todosImoveis.filter(imovel => {
        if (!imovel.lat || !imovel.lng) return false;
        const bounds = this.map.getBounds();
        const lat = parseFloat(imovel.lat);
        const lng = parseFloat(imovel.lng);
        return lat >= bounds.getSouth() &&
               lat <= bounds.getNorth() &&
               lng >= bounds.getWest() &&
               lng <= bounds.getEast();
      });
      this.aplicarFiltrosComAreaVisivel(imoveisNoMapa);
      this.atualizarMapa();
    },
    aplicarFiltroRapido(filtro) {
      this.limparFiltros();
      switch(filtro) {
        case 'venda':
          this.filtros.finalidade = 'Venda';
          break;
        case 'locacao':
          this.filtros.finalidade = 'Locação';
          break;
        case 'apartamento':
          this.filtros.tipo = 'Apartamento';
          break;
        case 'casa':
          this.filtros.tipo = 'Casa';
          break;
      }
      this.aplicarFiltros();
    },
    limparFiltros() {
      this.filtros = {
        bairro: '',
        cidade: '',
        precoMin: '',
        precoMax: '',
        tipo: '',
        finalidade: ''
      };
      this.imoveisFiltrados = [...this.todosImoveis];
      this.aplicarOrdenacao();
      this.atualizarMapa();
    },
    aplicarOrdenacao() {
      switch(this.ordenacao) {
        case 'preco-menor':
          this.imoveisFiltrados.sort((a, b) => parseFloat(a.valor) - parseFloat(b.valor));
          break;
        case 'preco-maior':
          this.imoveisFiltrados.sort((a, b) => parseFloat(b.valor) - parseFloat(a.valor));
          break;
        case 'recente':
          this.imoveisFiltrados.sort((a, b) => b.codigo - a.codigo);
          break;
        default:
          this.imoveisFiltrados.sort((a, b) => a.codigo - b.codigo);
      }
    },
    atualizarMapa() {
      if (!this.map || !this.map.getSource('imoveis')) return;
      const features = this.imoveisFiltrados
        .filter(imovel => imovel.lat && imovel.lng)
        .map(imovel => ({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [parseFloat(imovel.lng), parseFloat(imovel.lat)]
          },
          properties: {
            codigo: imovel.codigo,
            tipo: imovel.tipo,
            finalidade: imovel.finalidade,
            valor: imovel.valor,
            bairro: imovel.bairro,
            cidade: imovel.cidade,
            dormitorios: imovel.dormitorios,
            banheiros: imovel.banheiros,
            garagem: imovel.garagem,
            thumb_url: imovel.thumb_url
          }
        }));
      this.map.getSource('imoveis').setData({
        type: 'FeatureCollection',
        features: features
      });
      if (features.length > 0) {
        const coordinates = features.map(f => f.geometry.coordinates);
        const bounds = coordinates.reduce((bounds, coord) => {
          return bounds.extend(coord);
        }, new maplibregl.LngLatBounds(coordinates[0], coordinates[0]));
        this.map.fitBounds(bounds, { padding: 50 });
      }
    },
    abrirModal(imovelOuCodigo) {
      let imovel;
      if (typeof imovelOuCodigo === 'object') {
        imovel = imovelOuCodigo;
      } else {
        imovel = this.todosImoveis.find(i => i.codigo == imovelOuCodigo);
      }
      if (!imovel) return;
      this.imovelSelecionado = imovel;
      this.modalAberto = true;
      document.body.classList.add('overflow-hidden');
    },
    abrirSlideshow(index) {
      this.imagemAtualIndex = index;
      this.slideshowAberto = true;
      document.body.classList.add('overflow-hidden');
    },
    fecharSlideshow() {
      this.slideshowAberto = false;
      document.body.classList.remove('overflow-hidden');
    },
    proximaImagem() {
      if (this.imagemAtualIndex < (this.imovelSelecionado?.imagens?.length || 0) - 1) {
        this.imagemAtualIndex++;
      }
    },
    imagemAnterior() {
      if (this.imagemAtualIndex > 0) {
        this.imagemAtualIndex--;
      }
    },
    irParaImagem(index) {
      this.imagemAtualIndex = index;
    },
    fecharModal() {
      this.modalAberto = false;
      this.imovelSelecionado = null;
      document.body.classList.remove('overflow-hidden');
    },
    toggleFavorito(codigo) {
      const index = this.favoritos.indexOf(codigo);
      if (index > -1) {
        this.favoritos.splice(index, 1);
      } else {
        this.favoritos.push(codigo);
      }
      localStorage.setItem('favoritos', JSON.stringify(this.favoritos));
    },
    isFavorito(codigo) {
      return this.favoritos.includes(codigo);
    },
    async enviarMensagemChat() {
      if (!this.chatInput.trim()) return;
      const mensagemUsuario = this.chatInput.trim();
      this.adicionarMensagemChat('usuario', mensagemUsuario);
      this.chatInput = '';
      this.processandoChat = true;
      try {
        const resposta = await this.processarComIA(mensagemUsuario);
        this.adicionarMensagemChat('ia', resposta.mensagem);
        if (resposta.filtros) {
          this.aplicarFiltrosIA(resposta.filtros);
        }
      } catch (error) {
        console.error('Erro ao processar com IA:', error);
        this.adicionarMensagemChat('ia', 'Desculpe, ocorreu um erro ao processar sua solicitação. Tente novamente.');
      } finally {
        this.processandoChat = false;
      }
    },
    async processarComIA(mensagem) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      const filtros = this.extrairFiltrosDaMensagem(mensagem);
      let resposta = `Entendi! Você está procurando por ${filtros.descricao}. `;
      if (filtros.aplicados.length > 0) {
        resposta += `Apliquei os seguintes filtros: ${filtros.aplicados.join(', ')}. `;
      }
      resposta += `Encontrei ${this.imoveisFiltrados.length} imóveis que podem interessar você!`;
      return {
        mensagem: resposta,
        filtros: filtros.filtrosObj
      };
    },
    extrairFiltrosDaMensagem(mensagem) {
      const msg = mensagem.toLowerCase();
      const filtros = {};
      const aplicados = [];
      let descricao = 'um imóvel';
      if (msg.includes('apartamento') || msg.includes('ap')) {
        filtros.tipo = 'Apartamento';
        aplicados.push('Apartamento');
        descricao = 'um apartamento';
      } else if (msg.includes('casa')) {
        filtros.tipo = 'Casa';
        aplicados.push('Casa');
        descricao = 'uma casa';
      }
      if (msg.includes('aluguel') || msg.includes('locação') || msg.includes('alugar')) {
        filtros.finalidade = 'Locação';
        aplicados.push('para locação');
      } else if (msg.includes('venda') || msg.includes('comprar') || msg.includes('compra')) {
        filtros.finalidade = 'Venda';
        aplicados.push('para venda');
      }
      const bairros = ['itapoã', 'santa amélia', 'jardim canadá'];
      for (const bairro of bairros) {
        if (msg.includes(bairro)) {
          filtros.bairro = bairro.charAt(0).toUpperCase() + bairro.slice(1);
          aplicados.push(`no bairro ${filtros.bairro}`);
          break;
        }
      }
      const precoMatch = msg.match(/r\$?\s*(\d+(?:\.\d+)*)/i);
      if (precoMatch) {
        const preco = parseFloat(precoMatch[1].replace('.', ''));
        if (msg.includes('até') || msg.includes('máximo')) {
          filtros.precoMax = preco;
          aplicados.push(`até R$ ${preco.toLocaleString('pt-BR')}`);
        }
      }
      return {
        filtrosObj: filtros,
        aplicados,
        descricao
      };
    },
    aplicarFiltrosIA(filtros) {
      Object.assign(this.filtros, filtros);
      this.aplicarFiltros();
    },
    adicionarMensagemChat(tipo, texto) {
      const agora = new Date();
      this.historicoChat.push({
        tipo,
        texto,
        hora: agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      });
      this.$nextTick(() => {
        const chatContainer = document.querySelector('.bg-white.rounded-xl.border-2.border-gray-100');
        if (chatContainer) {
          chatContainer.scrollTop = chatContainer.scrollHeight;
        }
      });
    },
    limparChat() {
      this.chatInput = '';
      this.historicoChat = [];
    },
    async toggleGravacao() {
      if (this.gravandoAudio) {
        this.pararGravacao();
      } else {
        await this.iniciarGravacao();
      }
    },
    async iniciarGravacao() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        this.mediaRecorder = new MediaRecorder(stream);
        const chunks = [];
        this.mediaRecorder.ondataavailable = (event) => {
          chunks.push(event.data);
        };
        this.mediaRecorder.onstop = () => {
          this.audioBlob = new Blob(chunks, { type: 'audio/wav' });
          this.audioGravado = true;
          stream.getTracks().forEach(track => track.stop());
        };
        this.mediaRecorder.start();
        this.gravandoAudio = true;
      } catch (error) {
        console.error('Erro ao acessar microfone:', error);
        alert('Erro ao acessar o microfone. Verifique as permissões.');
      }
    },
    pararGravacao() {
      if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
        this.mediaRecorder.stop();
        this.gravandoAudio = false;
      }
    },
    async processarAudio() {
      if (!this.audioBlob) return;
      this.processandoAudio = true;
      try {
        await new Promise(resolve => setTimeout(resolve, 3000));
        const textoSimulado = "Procuro um apartamento de dois quartos no bairro Itapoã para alugar até dois mil reais";
        this.chatInput = textoSimulado;
        this.adicionarMensagemChat('usuario', `🎤 ${textoSimulado}`);
        await this.enviarMensagemChat();
        this.audioGravado = false;
        this.audioBlob = null;
      } catch (error) {
        console.error('Erro ao processar áudio:', error);
        this.adicionarMensagemChat('ia', 'Erro ao processar o áudio. Tente novamente.');
      } finally {
        this.processandoAudio = false;
      }
    },
    salvarApiKey() {
      localStorage.setItem('openai_api_key', this.openaiApiKey);
    },
    formatarMoeda(valor) {
      return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(parseFloat(valor));
    },
    limparDescricao(descricao) {
      return descricao
        .replace(/&#\d+;/g, '')
        .replace(/&[a-zA-Z]+;/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    }
  }
}).mount('#app');
window.appInstance = vueApp;
window.abrirModalGlobal = function(codigo) {
  if (window.appInstance && window.appInstance.abrirModal) {
    window.appInstance.abrirModal(codigo);
  }
};