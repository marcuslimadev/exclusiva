# Exclusiva Imóveis - Frontend Modernizado

Sistema moderno de busca e visualização de imóveis desenvolvido com Vue.js 3, Tailwind CSS e integração com APIs.

## 🚀 Funcionalidades

### ✅ Implementadas
- **Interface Moderna**: Design responsivo com gradientes e animações suaves
- **Sistema de Busca Avançado**: Filtros por bairro, cidade, preço, tipo e finalidade
- **Mapa Interativo**: Visualização geográfica dos imóveis com Leaflet
- **Modal Detalhado**: Galeria de fotos e especificações completas
- **Filtros Rápidos**: Botões para venda, locação, apartamentos e casas
- **Sistema de Favoritos**: Salva preferências no localStorage
- **Ordenação**: Por relevância, preço e data
- **Barra de Progresso**: Indicador visual de scroll
- **API Integrada**: Conecta com API externa e fallback local
- **Responsivo**: Otimizado para desktop e mobile

### 🎨 Design
- **Cores**: Paleta azul moderna com gradientes
- **Tipografia**: Inter font para melhor legibilidade
- **Animações**: Transições suaves e efeitos hover
- **Layout**: Cards em grid responsivo
- **Ícones**: Font Awesome 6.5.0

### 🛠️ Tecnologias
- **Vue.js 3**: Framework JavaScript reativo
- **Tailwind CSS**: Framework CSS utilitário
- **Leaflet**: Biblioteca de mapas interativos
- **Font Awesome**: Ícones vetoriais
- **Animate.css**: Animações CSS

## 📁 Estrutura do Projeto

```
exclusiva-imoveis-vue/
├── index.html          # Página principal
├── app.js             # Lógica Vue.js
├── style.css          # Estilos customizados
├── api_response.json  # Dados de exemplo da API
└── README.md          # Documentação
```

## 🔧 Configuração

### Pré-requisitos
- Servidor web (Apache, Nginx ou Python HTTP Server)
- API de imóveis funcionando

### Instalação
1. Clone ou baixe os arquivos do projeto
2. Configure um servidor web apontando para a pasta do projeto
3. Ajuste a URL da API no arquivo `app.js` (linha 238-239)
4. Acesse via navegador

### Servidor de Desenvolvimento
```bash
# Com Python
python3 -m http.server 8080

# Com Node.js
npx http-server -p 8080
```

## 🌐 API Integration

### Endpoints Suportados
- **API Externa**: `https://d3a4374bc57f.ngrok-free.app/exclusiva/api/imoveis.php`
- **API Local**: `../api/imoveis.php`
- **Fallback**: Dados locais em caso de falha

### Formato de Resposta
```json
{
  "status": true,
  "data": [
    {
      "codigo": 3900163,
      "referencia": "013AP",
      "finalidade": "Locação",
      "tipo": "Apartamento",
      "dormitorios": 2,
      "banheiros": 1,
      "garagem": 1,
      "valor": "1800.00",
      "cidade": "Belo Horizonte",
      "bairro": "Itapoã",
      "lat": "-19.84200940",
      "lng": "-43.96582740",
      "thumb_url": "url_da_imagem",
      "imagens": ["url1", "url2", "url3"],
      "descricao": "Descrição do imóvel..."
    }
  ]
}
```

## 🎯 Funcionalidades Detalhadas

### Sistema de Filtros
- **Busca por Texto**: Bairro e cidade
- **Filtro de Preço**: Valores mínimo e máximo
- **Filtros Rápidos**: Botões para categorias comuns
- **Ordenação**: Múltiplas opções de classificação

### Mapa Interativo
- **Markers Personalizados**: Cada imóvel no mapa
- **Popups Informativos**: Preview com foto e dados básicos
- **Zoom Automático**: Ajusta para mostrar todos os imóveis
- **Integração**: Clique no popup abre modal detalhado

### Modal de Detalhes
- **Galeria de Fotos**: Múltiplas imagens do imóvel
- **Especificações**: Informações técnicas completas
- **Ações**: Botões para WhatsApp e ligação
- **Navegação**: Tecla ESC para fechar

### Sistema de Favoritos
- **Persistência**: Salva no localStorage do navegador
- **Visual**: Ícone de coração nos cards
- **Toggle**: Adiciona/remove com um clique

## 📱 Responsividade

### Breakpoints
- **Mobile**: < 640px
- **Tablet**: 640px - 1024px  
- **Desktop**: > 1024px

### Adaptações Mobile
- Cards em coluna única
- Modal ocupa tela inteira
- Botões maiores para touch
- Menu colapsável

## 🎨 Customização

### Cores (Tailwind Config)
```javascript
colors: {
  primary: {
    500: '#3b82f6',
    600: '#2563eb',
    700: '#1d4ed8'
  }
}
```

### Animações Personalizadas
- **fade-in**: Entrada suave
- **slide-up**: Deslizamento vertical
- **bounce-in**: Entrada com bounce
- **pulse-slow**: Pulsação lenta

## 🔍 SEO e Performance

### Otimizações
- **Meta Tags**: Título e descrição otimizados
- **Lazy Loading**: Imagens carregadas sob demanda
- **Compressão**: CSS e JS minificados via CDN
- **Cache**: Favoritos salvos localmente

### Acessibilidade
- **Alt Text**: Imagens com texto alternativo
- **Keyboard Navigation**: Navegação por teclado
- **Screen Reader**: Labels semânticos
- **Contraste**: Cores com boa legibilidade

## 🚀 Deploy

### Opções de Hospedagem
1. **GitHub Pages**: Para sites estáticos
2. **Netlify**: Deploy automático
3. **Vercel**: Integração com Git
4. **Servidor Próprio**: Apache/Nginx

### Configurações de Servidor
```apache
# .htaccess para Apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^.*$ /index.html [L,QSA]
```

## 📊 Métricas de Performance

### Lighthouse Score (Estimado)
- **Performance**: 90+
- **Accessibility**: 95+
- **Best Practices**: 90+
- **SEO**: 85+

### Otimizações Aplicadas
- CDNs para bibliotecas externas
- Imagens otimizadas e lazy loading
- CSS crítico inline
- JavaScript não-bloqueante

## 🐛 Troubleshooting

### Problemas Comuns
1. **API não carrega**: Verificar CORS e URL
2. **Mapa não aparece**: Verificar conexão Leaflet
3. **Imagens quebradas**: Validar URLs das imagens
4. **Filtros não funcionam**: Verificar estrutura dos dados

### Debug
```javascript
// Ativar logs detalhados
console.log('Dados carregados:', this.todosImoveis);
console.log('Filtros aplicados:', this.filtros);
```

## 📝 Changelog

### v2.0.0 (Atual)
- ✅ Interface completamente redesenhada
- ✅ Vue.js 3 com Composition API
- ✅ Sistema de filtros avançado
- ✅ Mapa interativo com Leaflet
- ✅ Modal responsivo com galeria
- ✅ Sistema de favoritos
- ✅ Animações e transições suaves
- ✅ Integração com API externa
- ✅ Fallback para dados locais

### v1.0.0 (Original)
- Interface básica
- Listagem simples de imóveis
- Filtros limitados

## 🤝 Contribuição

Para contribuir com o projeto:
1. Fork o repositório
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## 📞 Suporte

Para suporte técnico:
- **Email**: contato@exclusivaimoveis.com.br
- **Telefone**: (31) 9999-9999
- **Endereço**: Belo Horizonte, MG

---

**Desenvolvido com ❤️ para Exclusiva Imóveis**

