// Configurações da aplicação Exclusiva Imóveis
const CONFIG = {
  // API OpenAI
  OPENAI_API_KEY: '', // Deixe vazio e configure através da interface
  OPENAI_API_BASE: 'https://api.openai.com/v1',
  
  // Configurações do mapa
  MAP_CENTER: [-43.9, -19.9], // Belo Horizonte
  MAP_ZOOM: 11,
  
  // URLs das APIs
  API_URLS: {
    EXTERNAL: 'https://ba0a3cd99855.ngrok-free.app/exclusiva/api/imoveis.php',
    LOCAL: '../api/imoveis.php'
  },
  
  // Configurações do chat
  CHAT_CONFIG: {
    MAX_MESSAGES: 50,
    TYPING_DELAY: 2000,
    AUDIO_MAX_DURATION: 60000 // 1 minuto
  },
  
  // Configurações de contato
  CONTACT: {
    WHATSAPP: '5531999999999',
    EMAIL: 'contato@exclusivaimoveis.com.br',
    PHONE: '(31) 9999-9999'
  }
};

// Função para obter a chave da API OpenAI
function getOpenAIKey() {
  return localStorage.getItem('openai_api_key') || CONFIG.OPENAI_API_KEY;
}

// Função para salvar a chave da API OpenAI
function setOpenAIKey(key) {
  localStorage.setItem('openai_api_key', key);
}

// Exportar configurações
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { CONFIG, getOpenAIKey, setOpenAIKey };
}

