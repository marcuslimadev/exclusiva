// Vue.js App
const { createApp } = Vue;

const vueApp = createApp({
  data() {
    return {
      loading: true,
      modalAberto: false,
      map: null,
      markersLayer: null,
      todosImoveis: [],
      imoveisFiltrados: [],
      imovelSelecionado: null,
      filtros: {
        bairro: '',
        cidade: '',
        precoMin: '',
        precoMax: ''
      },
      // Dados de fallback
      dadosImoveis: [
        {
          "codigo": 3900163,
          "referencia": "013AP",
          "finalidade": "Locação",
          "tipo": "Apartamento",
          "dormitorios": 2,
          "suites": 0,
          "banheiros": 1,
          "salas": 1,
          "garagem": 1,
          "valor": "1800.00",
          "cidade": "Belo Horizonte",
          "estado": "MG",
          "bairro": "Itapoã",
          "logradouro": "Avenida Portugal",
          "numero": "5425",
          "area_total": null,
          "descricao": "APARTAMENTO PARA LOCAÇÃO – BAIRRO ITAPOÃ. Valor R$ 1.800,00. Imóvel com excelente localização e fácil acesso às principais vias da região! Características: 02 quartos com armários planejados, 01 sala aconchegante com rebaixamento em gesso, 01 cozinha com revestimentos de qualidade e armários, 01 banheiro amplo com armário e box de vidro.",
          "lat": "-19.84200940",
          "lng": "-43.96582740",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604142998.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604142998.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604207451.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508221604202039.jpeg"
          ]
        },
        {
          "codigo": 3897176,
          "referencia": "066CA",
          "finalidade": "Venda",
          "tipo": "Casa",
          "dormitorios": 3,
          "suites": 3,
          "banheiros": 4,
          "salas": 0,
          "garagem": 2,
          "valor": "1980000.00",
          "cidade": "Nova Lima",
          "estado": "MG",
          "bairro": "Jardim Canadá",
          "logradouro": "Holanda",
          "numero": "36",
          "area_total": "370.00",
          "terreno": "531.00",
          "descricao": "Casa a venda no condomínio Ville Des Lacs R$ 1.980.000,00. Casa acabamento luxo no condomínio Ville des Lacs. Lote de 531m² com 370m² de área construída. 3 quartos sendo 1 suíte com amplo closet e 2 semi-suites.",
          "lat": "-20.06036970",
          "lng": "-43.97891510",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508210947339801.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508210947339801.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/20250821094739967.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508210947397768.jpeg"
          ]
        },
        {
          "codigo": 3891313,
          "referencia": "065AP",
          "finalidade": "Venda",
          "tipo": "Área Privativa",
          "dormitorios": 3,
          "suites": 0,
          "banheiros": 1,
          "salas": 1,
          "garagem": 1,
          "valor": "445000.00",
          "cidade": "Belo Horizonte",
          "estado": "MG",
          "bairro": "Santa Amélia",
          "logradouro": "Rua Professor Clóvis de Faria",
          "numero": "131",
          "area_total": "113.00",
          "descricao": "Oportunidade Imperdível no Bairro Santa Amélia. Imóvel com 3 quartos, localizado no 1º pavimento, perfeito para quem busca conforto e praticidade: 113m² de área total, 90m² de área construída.",
          "lat": "-19.84414770",
          "lng": "-43.97394230",
          "thumb_url": "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508181006316576.jpeg",
          "imagens": [
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508181006316576.jpeg",
            "https://imgs1.cdn-imobibrasil.com.br/imagens/imoveis/202508181006339633.jpeg"
          ]
        }
      ]
    }
  },

  computed: {
    contadorTexto() {
      const total = this.imoveisFiltrados.length;
      return total === 1 ? '1 imóvel encontrado' : `${total} imóveis encontrados`;
    },

    especificacoes() {
      if (!this.imovelSelecionado) return [];
      
      const specs = [
        { icon: 'fas fa-home', label: 'Tipo', value: this.imovelSelecionado.tipo },
        { icon: 'fas fa-calendar-alt', label: 'Finalidade', value: this.imovelSelecionado.finalidade },
        { icon: 'fas fa-bed', label: 'Dormitórios', value: this.imovelSelecionado.dormitorios || 0 },
        { icon: 'fas fa-bath', label: 'Banheiros', value: this.imovelSelecionado.banheiros || 0 },
        { icon: 'fas fa-car', label: 'Garagem', value: this.imovelSelecionado.garagem || 0 },
        { icon: 'fas fa-couch', label: 'Salas', value: this.imovelSelecionado.salas || 0 }
      ];
      
      if (this.imovelSelecionado.area_total) {
        specs.push({ icon: 'fas fa-ruler-combined', label: 'Área Total', value: `${this.imovelSelecionado.area_total} m²` });
      }
      
      if (this.imovelSelecionado.ano_construcao) {
        specs.push({ icon: 'fas fa-calendar', label: 'Ano', value: this.imovelSelecionado.ano_construcao });
      }
      
      return specs;
    },

    descricaoLimpa() {
      if (!this.imovelSelecionado?.descricao) return 'Descrição não disponível.';
      return this.limparDescricao(this.imovelSelecionado.descricao);
    }
  },

  mounted() {
    this.inicializarMapa();
    this.carregarImoveis();
    this.configurarEventos();
  },

  methods: {
    inicializarMapa() {
      this.map = L.map('map').setView([-19.9, -43.9], 11);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
      }).addTo(this.map);
      
      this.markersLayer = L.layerGroup().addTo(this.map);
    },

    configurarEventos() {
      // ESC para fechar modal
      document.addEventListener('keydown', (e) => {
        if (e.keyCode === 27 && this.modalAberto) {
          this.fecharModal();
        }
      });
    },

    async carregarImoveis() {
      this.loading = true;
      
      try {
        const response = await fetch('../api/imoveis.php', {
          method: 'GET',
          timeout: 3000
        });
        
        if (response.ok) {
          const data = await response.json();
          console.log('Dados carregados da API:', data);
          this.processarDados(data);
        } else {
          throw new Error('API não disponível');
        }
      } catch (error) {
        console.warn('API não disponível, usando dados locais:', error);
        this.processarDados({ data: this.dadosImoveis, status: true });
      }
    },

    processarDados(response) {
      this.loading = false;
      
      if (!response || !response.data || response.data.length === 0) {
        this.todosImoveis = [];
        this.imoveisFiltrados = [];
        return;
      }
      
      this.todosImoveis = response.data;
      this.imoveisFiltrados = [...this.todosImoveis];
      
      this.atualizarMapa();
    },

    aplicarFiltros() {
      const bairro = this.filtros.bairro.toLowerCase().trim();
      const cidade = this.filtros.cidade.toLowerCase().trim();
      const precoMin = parseFloat(this.filtros.precoMin) || 0;
      const precoMax = parseFloat(this.filtros.precoMax) || Infinity;
      
      this.imoveisFiltrados = this.todosImoveis.filter(imovel => {
        const precoBairro = !bairro || imovel.bairro.toLowerCase().includes(bairro);
        const precoCidade = !cidade || imovel.cidade.toLowerCase().includes(cidade);
        const valor = parseFloat(imovel.valor);
        const precoValido = valor >= precoMin && valor <= precoMax;
        
        return precoBairro && precoCidade && precoValido;
      });
      
      this.atualizarMapa();
    },

    atualizarMapa() {
      if (this.markersLayer) {
        this.markersLayer.clearLayers();
      }
      
      const bounds = [];
      
      this.imoveisFiltrados.forEach(imovel => {
        if (imovel.lat && imovel.lng) {
          const lat = parseFloat(imovel.lat);
          const lng = parseFloat(imovel.lng);
          
          const marker = L.marker([lat, lng]).addTo(this.markersLayer);
          const popupContent = this.criarPopupMapa(imovel);
          marker.bindPopup(popupContent, { maxWidth: 250 });
          
          bounds.push([lat, lng]);
        }
      });
      
      if (bounds.length > 0) {
        this.map.fitBounds(bounds, { padding: [20, 20] });
      }
    },

    criarPopupMapa(imovel) {
      const preco = this.formatarMoeda(imovel.valor);
      return `
        <div class="text-center">
          <img src="${imovel.thumb_url}" 
               style="width:100%; height:120px; object-fit:cover; border-radius:6px; margin-bottom:8px"
               onerror="this.style.display='none'">
          <h6 class="font-bold text-lg text-primary">${preco}</h6>
          <p class="text-gray-700 mb-2"><strong>${imovel.tipo}</strong></p>
          <p class="text-gray-600 text-sm mb-3">${imovel.bairro}</p>
          <button 
            onclick="window.abrirModalGlobal(${imovel.codigo})" 
            class="bg-primary hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition">
            Ver Detalhes
          </button>
        </div>
      `;
    },

    abrirModal(imovelOuCodigo) {
      let imovel;
      
      if (typeof imovelOuCodigo === 'object') {
        imovel = imovelOuCodigo;
      } else {
        imovel = this.todosImoveis.find(i => i.codigo == imovelOuCodigo);
      }
      
      if (!imovel) return;
      
      this.imovelSelecionado = imovel;
      this.modalAberto = true;
      document.body.classList.add('overflow-hidden');
    },

    fecharModal() {
      this.modalAberto = false;
      this.imovelSelecionado = null;
      document.body.classList.remove('overflow-hidden');
    },

    formatarMoeda(valor) {
      return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(parseFloat(valor));
    },

    limparDescricao(descricao) {
      return descricao
        .replace(/&#\d+;/g, '') // Remove HTML entities
        .replace(/&[a-zA-Z]+;/g, '') // Remove HTML entities nomeadas
        .replace(/\s+/g, ' ') // Remove espaços extras
        .trim();
    }
  }
}).mount('#app');

// Guardar referência global da instância Vue
appInstance = app;

// Função global para ser chamada pelos popups do mapa
window.abrirModalGlobal = function(codigo) {
  if (appInstance && appInstance.abrirModal) {
    appInstance.abrirModal(codigo);
  }
};